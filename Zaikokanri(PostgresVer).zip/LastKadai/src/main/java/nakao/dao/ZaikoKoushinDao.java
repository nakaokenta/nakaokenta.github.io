package nakao.dao;

import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import nakao.form.KoushinForm;

public interface ZaikoKoushinDao {
	List<Map<String,Object>> getZaikoKoushin0List() throws DataAccessException;
	List<Map<String,Object>> getZaikoKoushinList(String result) throws DataAccessException;
	List<Map<String,Object>> getZaikoKoushin2List() throws DataAccessException;
	int updateZaikoKoushin(KoushinForm koushinForm) throws DataAccessException;
	int updateZaikoKoushin2(KoushinForm koushinForm,String baseCode,String result) throws DataAccessException;
	int updateZaikoKoushin3(KoushinForm koushinForm,String baseCode) throws DataAccessException;
}

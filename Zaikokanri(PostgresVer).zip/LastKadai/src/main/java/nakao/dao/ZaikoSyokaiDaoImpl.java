package nakao.dao;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;

import nakao.form.SyokaiForm;

public class ZaikoSyokaiDaoImpl extends NamedParameterJdbcDaoSupport implements ZaikoSyokaiDao {
	public List<Map<String, Object>> getZaikoSyokaiList() throws DataAccessException {
		return getJdbcTemplate().queryForList("SELECT * FROM ZAIKO_SYOUHIN LEFT JOIN ZAIKO_MAKER ON ZAIKO_SYOUHIN.S_MAKER_CODE = ZAIKO_MAKER.M_CODE LEFT JOIN ZAIKO_ORDER ON ZAIKO_SYOUHIN.S_CODE = ZAIKO_ORDER.O_SYOUHIN_CODE ORDER BY M_NAME,S_CODE");
	}
	
	public List<Map<String, Object>> getZaikoSyokai3List() throws DataAccessException {
		return getJdbcTemplate().queryForList("SELECT M_NAME FROM ZAIKO_MAKER GROUP BY M_NAME ORDER BY M_NAME");
	}
	
	public List<Map<String, Object>> getZaikoSyokai4List() throws DataAccessException {
		return getJdbcTemplate().queryForList("SELECT S_CODE FROM ZAIKO_SYOUHIN ORDER BY S_CODE");
	}
	
	public List<Map<String, Object>> getZaikoSyokai5List() throws DataAccessException {
		return getJdbcTemplate().queryForList("SELECT S_NAME,S_CODE FROM ZAIKO_SYOUHIN ORDER BY S_NAME");
	}
	
	public List<Map<String,Object>> getZaikoSyokai0List(String a) throws DataAccessException {
		String sql = "SELECT S_CODE FROM ZAIKO_SYOUHIN LEFT JOIN ZAIKO_MAKER  ON ZAIKO_SYOUHIN.S_MAKER_CODE = ZAIKO_MAKER.M_CODE WHERE M_NAME = :M_NAME ORDER BY S_CODE";
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("M_NAME", a);
		return getNamedParameterJdbcTemplate().queryForList(sql,parameters);
	}
	public List<Map<String,Object>> getZaikoSyokai00List(String a) throws DataAccessException {
		String sql = "SELECT S_CODE,S_NAME FROM ZAIKO_SYOUHIN LEFT JOIN ZAIKO_MAKER  ON ZAIKO_SYOUHIN.S_MAKER_CODE = ZAIKO_MAKER.M_CODE WHERE M_NAME = :M_NAME ORDER BY S_CODE";
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("M_NAME", a);
		return getNamedParameterJdbcTemplate().queryForList(sql,parameters);
	}
	
	
	public List<Map<String, Object>> getZaikoSyokai2List(SyokaiForm syokaiForm) throws DataAccessException {
		
		String sql = "SELECT * FROM ZAIKO_SYOUHIN LEFT JOIN ZAIKO_MAKER ON ZAIKO_SYOUHIN.S_MAKER_CODE = ZAIKO_MAKER.M_CODE LEFT JOIN ZAIKO_ORDER ON ZAIKO_SYOUHIN.S_CODE = ZAIKO_ORDER.O_SYOUHIN_CODE";
		String where = "";
		Map<String, Object> parameters = new HashMap<String, Object>();
		String s1 = syokaiForm.getMakerName();
		String s2 = syokaiForm.getItemCode();
		String s3 = syokaiForm.getItemName();
		String s4 = syokaiForm.getPrice();
		Integer i4 = 0;
		if(!"".equals(s4)) {
			i4 = Integer.valueOf(s4);
		}
		String s5 = syokaiForm.getStock();
		Integer i5 = 0;
		if(!"".equals(s5)) {
			i5 = Integer.valueOf(s5);
		}		
		if(!"".equals(s1) && "yes".equals(syokaiForm.getR1())) {
			where += " AND M_NAME = :M_NAME";
			parameters.put("M_NAME", s1);
		} else if(!"".equals(s1) && "no".equals(syokaiForm.getR1())) {
			where += " AND M_NAME != :M_NAME";
			parameters.put("M_NAME", s1);
		}
		
		if(!"".equals(s2) && "yes".equals(syokaiForm.getR2())) {
			where += " AND S_CODE = :S_CODE";
			parameters.put("S_CODE", s2);
		} else if (!"".equals(s2) && "no".equals(syokaiForm.getR2())) {
			where += " AND S_CODE != :S_CODE";
			parameters.put("S_CODE", s2);
		}
		
		if(!"".equals(s3) && "yes".equals(syokaiForm.getR3())) {
			where += " AND S_NAME = :S_NAME";
			parameters.put("S_NAME", s3);
		} else if(!"".equals(s3) && "no".equals(syokaiForm.getR3())) {
			where += " AND S_NAME != :S_NAME";
			parameters.put("S_NAME", s3);
		}
		
		if(!"".equals(s4) && "yes".equals(syokaiForm.getR4())) {
			where += " AND S_PRICE >= :S_PRICE";
			parameters.put("S_PRICE", i4);
		} else if(!"".equals(s4) && "no".equals(syokaiForm.getR4())) {
			where += " AND S_PRICE < :S_PRICE";
			parameters.put("S_PRICE", i4);
		}
		
		if(!"".equals(s5) && "yes".equals(syokaiForm.getR5())) {
			where += " AND O_STOCK >= :O_STOCK";
			parameters.put("O_STOCK", i5);
		} else if(!"".equals(s5) && "no".equals(syokaiForm.getR5())) {
			where += " AND O_STOCK < :O_STOCK";
			parameters.put("O_STOCK", i5);
		}
		
		if(!where.isEmpty()) {
			sql += " WHERE" + where.substring(4) + " ORDER BY M_NAME,S_CODE";
		} else {
			sql +=  " ORDER BY M_NAME,S_CODE";
		}
		
		where = "";
		return getNamedParameterJdbcTemplate().queryForList(sql,parameters);
	}
	
	public List<Map<String, Object>> getZaikoKoushinList(String a) throws DataAccessException {
		String sql = "SELECT * FROM ZAIKO_SYOUHIN LEFT JOIN ZAIKO_MAKER  ON ZAIKO_SYOUHIN.S_MAKER_CODE = ZAIKO_MAKER.M_CODE WHERE S_CODE = :S_CODE";
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("S_CODE", a);
		return getNamedParameterJdbcTemplate().queryForList(sql,parameters);
	}
			

}

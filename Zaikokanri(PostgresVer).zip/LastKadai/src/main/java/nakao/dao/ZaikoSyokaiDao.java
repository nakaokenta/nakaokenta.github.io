package nakao.dao;


import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import nakao.form.SyokaiForm;

public interface ZaikoSyokaiDao {
	List<Map<String,Object>> getZaikoSyokaiList() throws DataAccessException;
	
	List<Map<String,Object>> getZaikoSyokai2List(SyokaiForm syokaiForm) throws DataAccessException;
	
	List<Map<String,Object>> getZaikoSyokai3List() throws DataAccessException;
	
	List<Map<String,Object>> getZaikoSyokai4List() throws DataAccessException;
	
	List<Map<String,Object>> getZaikoSyokai5List() throws DataAccessException;
	
	List<Map<String, Object>> getZaikoSyokai0List(String a) throws DataAccessException;
	
	List<Map<String, Object>> getZaikoSyokai00List(String a) throws DataAccessException;
	
	List<Map<String, Object>> getZaikoKoushinList(String a) throws DataAccessException;
}

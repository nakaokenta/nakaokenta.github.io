package nakao.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;

import nakao.form.TsuikaForm;

public class ZaikoTsuikaDaoImpl extends NamedParameterJdbcDaoSupport implements ZaikoTsuikaDao {
	
	public List<Map<String,Object>> getZaikoTsuika0List(){
		return getJdbcTemplate().queryForList("SELECT S_CODE FROM ZAIKO_SYOUHIN");
	}
	
	public List<Map<String,Object>> getZaikoTsuikaList(){
		return getJdbcTemplate().queryForList("SELECT M_NAME,M_CODE FROM ZAIKO_MAKER");
	}
	
	public int updateZaikoTsuika(TsuikaForm tsuikaForm) {
		String s1 = tsuikaForm.getMakerName();
		String sql ="INSERT INTO ZAIKO_MAKER VALUES(TO_CHAR(NEXTVAL('NAKAO0903'), 'FM000'), ?)";
		return getJdbcTemplate().update(sql,s1);
	}
	
	public int updateZaikoTsuika2(TsuikaForm tsuikaForm,String result) {
		String s2 = tsuikaForm.getItemCode();
		String s3 = tsuikaForm.getItemName();
		String s4 = tsuikaForm.getPrice();
		Integer i4 = Integer.valueOf(s4);
		String sql ="INSERT INTO ZAIKO_SYOUHIN VALUES(:S_CODE,:S_NAME,:M_CODE,:S_PRICE)";
		
		
		
		
		
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("S_CODE",s2);
		parameters.put("S_NAME",s3);
		parameters.put("M_CODE",result);
		parameters.put("S_PRICE",i4);
		return getNamedParameterJdbcTemplate().update(sql,parameters);
	}
	
	
	public int updateZaikoTsuika3(TsuikaForm tsuikaForm) {
		String s1 = tsuikaForm.getItemCode();
		String sql = "INSERT INTO ZAIKO_ORDER VALUES(?,0,0,0)";
		return getJdbcTemplate().update(sql,s1);
	}
}

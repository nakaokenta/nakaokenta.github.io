package nakao.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;

import nakao.form.KoushinForm;

public class ZaikoKoushinDaoImpl extends NamedParameterJdbcDaoSupport implements ZaikoKoushinDao {
	
	public List<Map<String, Object>> getZaikoKoushin0List() throws DataAccessException {
		return getJdbcTemplate().queryForList("SELECT S_CODE FROM ZAIKO_SYOUHIN");
	}
	
	public List<Map<String,Object>> getZaikoKoushinList(String result){
		String sql = "SELECT * FROM ZAIKO_SYOUHIN LEFT JOIN ZAIKO_MAKER ON ZAIKO_SYOUHIN.S_MAKER_CODE = ZAIKO_MAKER.M_CODE WHERE S_CODE = :S_CODE";
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("S_CODE",result);
		return getNamedParameterJdbcTemplate().queryForList(sql,parameters);
	}
	
	public List<Map<String, Object>> getZaikoKoushin2List() throws DataAccessException {
		return getJdbcTemplate().queryForList("SELECT * FROM ZAIKO_MAKER");
	}
	
	
	public int updateZaikoKoushin(KoushinForm koushinForm) {
		String s1 = koushinForm.getMakerName();
		String sql ="INSERT INTO ZAIKO_MAKER VALUES(TO_CHAR(NEXTVAL('NAKAO0903'), 'FM000'), ?)";
		return getJdbcTemplate().update(sql,s1);
	}
	
	public int updateZaikoKoushin2(KoushinForm koushinForm,String baseCode,String result) {
		String s1 = koushinForm.getItemCode();
		String s2 = koushinForm.getItemName();
		String s3 = koushinForm.getPrice();
		Integer i3 = Integer.valueOf(s3);
		String sql ="UPDATE ZAIKO_SYOUHIN SET S_CODE = ?, S_NAME = ?, S_MAKER_CODE = ?, S_PRICE = ? WHERE S_CODE = ?";                                     
		return getJdbcTemplate().update(sql,s1,s2,result,i3,baseCode);
	}
	
	public int updateZaikoKoushin3(KoushinForm koushinForm,String baseCode) {
		String s1 = koushinForm.getItemCode();
		String sql ="UPDATE ZAIKO_ORDER SET O_SYOUHIN_CODE = ? WHERE O_SYOUHIN_CODE = ?";
		return getJdbcTemplate().update(sql,s1,baseCode);
	}
	
}

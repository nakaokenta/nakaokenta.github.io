package nakao.dao;

import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import nakao.form.TsuikaForm;

public interface ZaikoTsuikaDao {
	List<Map<String,Object>> getZaikoTsuika0List() throws DataAccessException;
	List<Map<String,Object>> getZaikoTsuikaList() throws DataAccessException;
	int updateZaikoTsuika(TsuikaForm tsuikaForm) throws DataAccessException;
	int updateZaikoTsuika2(TsuikaForm tsuikaForm, String result) throws DataAccessException;
	int updateZaikoTsuika3(TsuikaForm tsuikaForm) throws DataAccessException;
}

package nakao.form;

public class SakuzyoForm {
	
	private String but;
	
	private String authority = null;
	
	public String getBut() {
		return but;
	}
	public void setBut(String but) {
		this.but = but;
	}
	
	public String getAuthority() {
		return authority;
	}
	public void setAuthority(String authority) {
		this.authority = authority;
	}
}

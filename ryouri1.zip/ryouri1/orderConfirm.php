<?php
session_start();
require_once('data.php');
?>
<?php
    $user = "yuiop0511";
    $password = "yuiop0511";
    $dbName = "ryouri1";
    $host = "localhost:3306";
    $dsn = "mysql:host={$host};dbname={$dbName};charset=utf8";
    try {
        $pdo = new PDO($dsn, $user, $password);
        $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch(Exception $e) {
        echo "エラーがありました。<br>";
        echo $e->getMessage();
        exit();
    }

    try {
        $pdo->beginTransaction();
        $sql1 = "INSERT INTO ordermenu (o_menu_code,o_count,o_sum,o_time) VALUES (:o_menu_code,:o_count,:o_sum,:o_time)";
        $sql2 = "INSERT INTO menu (m_code,m_name,m_price) VALUES (:m_code,:m_name,:m_price)";
        $sql3 = "SELECT * FROM menu WHERE m_code = :m_code";
        $insertOrder = $pdo->prepare($sql1);
        $selectMenu = $pdo->prepare($sql3);
        foreach($menus as $menu) {
            $menuCode = $menu->getMenuCode();
            $menuName = $menu->getName();
            $orderCount = $_SESSION['\''.$menu->getName().'\''];
            $menu->setOrderCount($orderCount);
            $taxIncludedPrice = $menu->getTaxIncludedPrice();
            $totalPrice = $menu->getTotalPrice();
            $now = date('Y/m/d H:i:s');
            
            $insertOrder->bindValue(':o_menu_code',$menuCode,PDO::PARAM_STR);
            $insertOrder->bindValue(':o_count',$orderCount,PDO::PARAM_STR);
            $insertOrder->bindValue(':o_sum',$totalPrice,PDO::PARAM_INT);
            $insertOrder->bindValue(':o_time',$now,PDO::PARAM_STR);
            $insertOrder->execute();

            $selectMenu->bindValue(':m_code',$menuCode,PDO::PARAM_STR);
            $selectMenu->execute();
            $result = $selectMenu->fetchAll(PDO::FETCH_ASSOC);
            if(count($result) == 0) {
                $insertMenu = $pdo->prepare($sql2);
                $insertMenu->bindValue(':m_code',$menuCode,PDO::PARAM_STR);
                $insertMenu->bindValue(':m_name',$menuName,PDO::PARAM_STR);
                $insertMenu->bindValue(':m_price',$taxIncludedPrice,PDO::PARAM_INT);
                $insertMenu->execute();
            }
        }
        killSession();
        $pdo->commit();
    } catch(Exception $e) {
        $pdo->rollback();
        echo "エラーがありました2。<br>";
        echo $e->getMessage();
        exit();
    }

    function killSession() {
        $_SESSION = [];
        session_destroy();
    }

?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="utf-8">
    <title>Cafe Kenta</title>
    <link rel="stylesheet" type="text/css" href="stylesheet.css">
    <link rel="https://fonts.googleapis.com/css?family=Pacifico|Lato" rel="stylesheet" type="text/css">
</head>
<body>
    <div class="order-wrapper">
        <h2>ありがとうございます!!</h2>
        <h2>ご注文を受け付けました。</h2>
        <a href="top.php">← メニュー一覧へ</a>
    </div>
</body>
</html>
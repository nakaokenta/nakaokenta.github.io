<?php
    if(isset($_COOKIE["visitedCount"])) {
        $visitedCount = $_COOKIE["visitedCount"];
    } else {
        $visitedCount = 0;
    }
    $result = setcookie("visitedCount", ++$visitedCount, time()+60*5);
?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="utf-8">
    <title>Cafe Kenta</title>
    <link rel="stylesheet" type="text/css" href="stylesheet.css">
    <link href="https://fonts.googleapis.com/css?family=Pacifico&display=swap" rel="stylesheet">
</head>
<body>
    <div class="menu-wrapper container">
        <h1 class="logo">Cafe Kenta</h1>
        <h2 class="logo2">--welcome to my cafe!!!--</h2>
        <?php
            if($result) {
                echo '<div class="visitedCount">You are '.$visitedCount.' th Guest.</div>';
            }
        ?>
        <h3><a href="top.php">← メニュー一覧へ</a></h3>
    </div>
</body>
</html>
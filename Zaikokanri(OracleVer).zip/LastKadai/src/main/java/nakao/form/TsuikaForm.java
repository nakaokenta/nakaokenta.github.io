package nakao.form;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

public class TsuikaForm {

	@NotEmpty(message="メーカー名を入力してください。")
	@Size(min=1,max=6,message="メーカー名は全角6文字以内で入力してください。")
	private String makerName;
	
	@NotEmpty(message="商品コードを入力してください。")
	@Size(min=6,max=6,message="商品コードは半角英数字6文字で入力してください。")
	@Pattern(regexp="[a-zA-Z0-9]*", message="商品コードは半角英数字で入力してください。")
	private String itemCode;
	
	@NotEmpty(message="商品名称を入力してください。")
	@Size(min=1,max=6,message="商品名称は全角6文字以内で入力してください。")
	private String itemName;
	
	@NotEmpty(message="単価を入力してください。")
	@Pattern(regexp="[0-9]*", message="単価は半角数字を入力してください。")
	@Range(min=1,max=99999999, message="単価は{min}～{max}で入力してください。")
	@Size(max=8,message="単価は{max}桁以内で入力してください。")
	private String price;
	
	private String authority = null;
	
	public String getMakerName() {
		return makerName;
	}
	public void setMakerName(String makerName) {
		this.makerName = makerName;
	}
	
	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	
	public String getAuthority() {
		return authority;
	}
	public void setAuthority(String authority) {
		this.authority = authority;
	}
}


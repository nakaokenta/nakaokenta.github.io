package nakao.form;


import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

public class SyokaiForm {
	
	private String but; 
	private String authority = null;
	
	private String makerName;
	private String itemCode;
	private String itemCode2;
	private String itemName;
	private String price;
	private String stock;
	
	@NotEmpty(message="受注数量を入力してください。")
	@Pattern(regexp="[0-9]*", message="受注数量は半角数字を入力してください。")
	@Range(min=1,max=99999999, message="受注数量は{min}～{max}で入力してください。")
	@Size(max=8,message="受注数量は{max}桁以内で入力してください。")
	private String accept;
	
	private String request;
	
	private String r1;
	private String r2;
	private String r3;
	private String r4;
	private String r5;
	
	private String id;
	private String pass;
	
	private String before;
	private String after;
	
	public String getBut() {
		return but;
	}
	public void setBut(String but) {
		this.but = but;
	}
	public String getMakerName() {
		return makerName; 
	}
	public void setMakerName(String makerName) {
		this.makerName = makerName;
	}
	public String getItemCode() {
		return itemCode; 
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	public String getItemCode2() {
		return itemCode2; 
	}
	public void setItemCode2(String itemCode2) {
		this.itemCode2 = itemCode2;
	}
	public String getItemName() {
		return itemName; 
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getPrice() {
		return price; 
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getStock() {
		return stock; 
	}
	public void setStock(String stock) {
		this.stock = stock;
	}
	public String getAccept() {
		return accept;
	}
	public void setAccept(String accept) {
		this.accept = accept;
	}
	public String getRequest() {
		return request;
	}
	public void setRequest(String request) {
		this.request = request;
	}
	
	public String getR1() {
		return r1;
	}
	public void setR1(String r1) {
		this.r1 = r1;
	}
	public String getR2() {
		return r2;
	}
	public void setR2(String r2) {
		this.r2 = r2;
	}
	public String getR3() {
		return r3;
	}
	public void setR3(String r3) {
		this.r3= r3;
	}
	public String getR4() {
		return r4;
	}
	public void setR4(String r4) {
		this.r4 = r4;
	}
	public String getR5() {
		return r5;
	}
	public void setR5(String r5) {
		this.r5 = r5;
	}
	
	public String getId() {
		return id; 
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPass() {
		return pass; 
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	
	public String getBefore() {
		return before; 
	}
	public void setBefore(String before) {
		this.before = before;
	}
	public String getAfter() {
		return after; 
	}
	public void setAfter(String after) {
		this.after = after;
	}
	
	public String getAuthority() {
		return authority;
	}
	public void setAuthority(String authority) {
		this.authority = authority;
	}
}

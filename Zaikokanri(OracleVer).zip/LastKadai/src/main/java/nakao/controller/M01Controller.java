package nakao.controller;

import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import nakao.dao.ZaikoUsersDao;
import nakao.form.LoginForm;

@Controller
public class M01Controller {
	
	@Autowired
	private HttpSession session; 
	
	private ZaikoUsersDao zaikoUsersDao;
	
	public void setZaikoUsersDao(ZaikoUsersDao zaikoUsersDao) {
		this.zaikoUsersDao = zaikoUsersDao;
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.GET)
    public String top(Model model) {

           return "login";
    }
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
    public String login(Model model, @ModelAttribute("login") LoginForm loginForm) {
		
		
		String id = loginForm.getId();
    	String pass = loginForm.getPass();
		int flg = 0;
    	
		ArrayList<Map<String, Object>>  list =  (ArrayList<Map<String, Object>>) zaikoUsersDao.getZaikoUsersList();
		
		for(Map<String, Object> map : list) {
			if (map.get("ID").equals(id) && map.get("PASS").equals(pass)) {
				flg = 1;
				loginForm.setAuthority((String) map.get("AUTHORITY"));
				loginForm.setName((String) map.get("NAME"));
				break;
			}
		}
		session.setAttribute("AUTHORITY", loginForm.getAuthority());
		model.addAttribute("loginForm",loginForm.getAuthority());
		
		if(flg == 1) {
			model.addAttribute("login",loginForm);
			return "layout1";
		} else {
			model.addAttribute("errMessage", "USER IDかPASSWORDが間違っています。");
			return "login";
		}
	}
	
	@RequestMapping(value = "/login", params="0", method = RequestMethod.POST)
	public String logout(Model model, @ModelAttribute("login") LoginForm loginForm) {
		model.addAttribute("errMessage","ログアウトしました。");
		return "login";
	}
	
	@RequestMapping(value = "/syokai", params="1", method = RequestMethod.POST)
	public String syokai1(Model model, @ModelAttribute("syokai") LoginForm loginForm) {
		model.addAttribute("loginForm",loginForm.getAuthority());
		return "layout2";
	}
}

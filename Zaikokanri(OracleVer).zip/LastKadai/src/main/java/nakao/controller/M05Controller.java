package nakao.controller;

import java.util.ArrayList;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import nakao.dao.ZaikoKoushinDao;
import nakao.form.KoushinForm;

@Controller
public class M05Controller {
	private ZaikoKoushinDao zaikoKoushinDao;
	
	public void setZaikoKoushinDao(ZaikoKoushinDao zaikoKoushinDao) {
		this.zaikoKoushinDao = zaikoKoushinDao;
	}
	
	@RequestMapping(value = "/koushin2", params="koushin2", method = RequestMethod.POST)
	public String koushin1(Model model,@Valid @ModelAttribute("koushin2") KoushinForm koushinForm, BindingResult results) {
		model.addAttribute("syokaiForm",koushinForm);
		model.addAttribute("loginForm",koushinForm.getAuthority());
		
		if(results.hasErrors()) {
			return "layout11";
		}
		
		String s1 = koushinForm.getMakerName();
		String s2 = koushinForm.getItemCode();
		String s22 = koushinForm.getItemCode2();
		String result0 = "";
		String result1 = "";
		String result2 = "";
		String result3 = "";
		String result4 = "";
		String result5 = "";
		String result6 = "";
		int flg = 0;
		int flg2 = 0;
		int flg3 = 0;
		
		ArrayList<Map<String,Object>> list0 = (ArrayList<Map<String,Object>>) zaikoKoushinDao.getZaikoKoushin0List();
		for(Map<String, Object> map0 : list0) {
			result0 = (String) map0.get("S_CODE");
			if(s2.equals(result0) && !s2.equals(s22)) {
				model.addAttribute("result", "入力された商品コードが存在しています。別の商品コードを入力してください。");
				return "layout11";
			}
		}
		
		
		ArrayList<Map<String,Object>> list3 = (ArrayList<Map<String, Object>>) zaikoKoushinDao.getZaikoKoushinList(s22);
		
			for(Map<String, Object> map3 :list3) {
				result1 = (String) map3.get("M_NAME");
				result2 = (String) map3.get("M_CODE");
				if(s1.equals(result1)) {
					result3 = result2;
					flg = 1;
					break;
				}
			}
			if(s2.equals(s22)) {
				flg2 = 1;
			}
		
		
		if(flg == 1 && flg2 == 1) {
			int updateResult1 = zaikoKoushinDao.updateZaikoKoushin2(koushinForm,s22,result3);
			if(updateResult1 == 1) {
				model.addAttribute("result", "商品の更新が正常に完了しました。");
			}
		} else if(flg != 1 && flg2 == 1) {
			ArrayList<Map<String,Object>> list22 = (ArrayList<Map<String,Object>>) zaikoKoushinDao.getZaikoKoushin2List();
			for(Map<String, Object> map22 : list22) {
				result4 = (String) map22.get("M_NAME");
				result5 = (String) map22.get("M_CODE");
				if(s1.equals(result4)) {
					flg3 = 1;
					break;
				}
			}
			if (flg3 !=1) {
				int updateResult0 = zaikoKoushinDao.updateZaikoKoushin(koushinForm);
			}
			ArrayList<Map<String,Object>> list2 = (ArrayList<Map<String,Object>>) zaikoKoushinDao.getZaikoKoushin2List();
			for(Map<String, Object> map2 : list2) {
				result4 = (String) map2.get("M_NAME");
				result5 = (String) map2.get("M_CODE");
				if(s1.equals(result4)) {
					result6 = result5;
					break;
				}
			}
			int updateResult1 = zaikoKoushinDao.updateZaikoKoushin2(koushinForm,s22,result6);
			if(updateResult1 == 1) {
				model.addAttribute("result", "商品の更新が正常に完了しました。");
			}
		} else if(flg == 1 && flg2 != 1) {
			int updateResult1 = zaikoKoushinDao.updateZaikoKoushin2(koushinForm,s22,result3);
			int updateResult2 = zaikoKoushinDao.updateZaikoKoushin3(koushinForm,s22);
			if(updateResult1 == 1) {
				model.addAttribute("result", "商品の更新が正常に完了しました。");
			}
		} else if(flg != 1 && flg2 != 1) {
			ArrayList<Map<String,Object>> list22 = (ArrayList<Map<String,Object>>) zaikoKoushinDao.getZaikoKoushin2List();
			for(Map<String, Object> map22 : list22) {
				result4 = (String) map22.get("M_NAME");
				result5 = (String) map22.get("M_CODE");
				if(s1.equals(result4)) {
					flg3 = 1;
					break;
				}
			}
			if (flg3 !=1) {
				int updateResult0 = zaikoKoushinDao.updateZaikoKoushin(koushinForm);
			}
			ArrayList<Map<String,Object>> list4 = (ArrayList<Map<String,Object>>) zaikoKoushinDao.getZaikoKoushin2List();
			for(Map<String, Object> map4 : list4) {
				result4 = (String) map4.get("M_NAME");
				result5 = (String) map4.get("M_CODE");
				if(s1.equals(result4)) {
					result6 = result5;
					break;
				}
			}
			int updateResult1 = zaikoKoushinDao.updateZaikoKoushin2(koushinForm,s22,result6);
			int updateResult2 = zaikoKoushinDao.updateZaikoKoushin3(koushinForm,s22);
			if(updateResult1 == 1 && updateResult2 == 1) {
				model.addAttribute("result", "商品の追加が正常に完了しました。");
			}
		}
		
		return "layout9";
	}
}

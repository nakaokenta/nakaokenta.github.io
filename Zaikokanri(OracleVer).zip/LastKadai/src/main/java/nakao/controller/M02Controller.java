package nakao.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import nakao.dao.ZaikoSyokaiDao;
import nakao.form.KoushinForm;
import nakao.form.SyokaiForm;

@Controller
public class M02Controller {

	private ZaikoSyokaiDao zaikoSyokaiDao;
	
	
	public void setZaikoSyokaiDao(ZaikoSyokaiDao zaikoSyokaiDao) {
		this.zaikoSyokaiDao = zaikoSyokaiDao;
	}
	
	
	@RequestMapping(value="/syokai", params="syokai1", method = RequestMethod.POST)
		public String syokai(Model model, @ModelAttribute("syokai") SyokaiForm syokaiForm) {
		model.addAttribute("syokaiForm",syokaiForm);
		model.addAttribute("loginForm",syokaiForm.getAuthority());
			
		ArrayList<Map<String, Object>> list = (ArrayList<Map<String, Object>>) zaikoSyokaiDao.getZaikoSyokai2List(syokaiForm);
			
		if(list.size() == 0) {
			model.addAttribute("result0","検索結果は0件です。");
			return "layout2";
		} else {
			model.addAttribute("data",list);
			return "layout3";
		}
		
		
				
			
		
		
		}
	
	 @RequestMapping(value = "/syokai", params="back", method = RequestMethod.POST)
	 public String form(Model model, @ModelAttribute("syokai") SyokaiForm syokaiForm) {
		 model.addAttribute("loginForm",syokaiForm.getAuthority());
    	String beforeS = syokaiForm.getBefore();
    	
    	String s1 = syokaiForm.getMakerName();
		String r1 = syokaiForm.getR1();
		String s2 = syokaiForm.getItemCode();
		String r2 = syokaiForm.getR2();
		String s3 = syokaiForm.getItemName();
		String r3 = syokaiForm.getR3();
		String s4 = syokaiForm.getPrice();
		String r4 = syokaiForm.getR4();
		if (s4.equals("")) {
			r4 = "no";
		}
		String s5 = syokaiForm.getStock();
		String r5 = syokaiForm.getR5();
		if (s5.equals("")) {
			r5 = "no";
		}
		
    	ArrayList<Map<String, Object>>  list =  (ArrayList<Map<String, Object>>) zaikoSyokaiDao.getZaikoSyokai2List(syokaiForm);
    	
    	ArrayList<Map<String,Object>> list2 = new ArrayList<Map<String,Object>>();
    	
    	int flg = 0;
    	
    	for(Map<String, Object> map : list) {
			
			if ("".equals(s1) && "".equals(s2) && "".equals(s3) && "".equals(s4) && "".equals(s5)) {
				flg = 1;
			}
			
			Object obj = map.get("S_PRICE");
			Object obj2 = map.get("O_STOCK");
			if((map.get("M_NAME").equals(s1) && r1.equals("yes")) || (map.get("S_CODE").equals(s2) && r2.equals("yes")) || (map.get("S_NAME").equals(s3) && r3.equals("yes")) || r4.equals("yes") && (Integer.parseInt(obj.toString()) >= Integer.parseInt(s4)) || r5.equals("yes") && (Integer.parseInt(obj2.toString()) >= Integer.parseInt(s5))) {
				System.out.println(map);
				list2.add(map);
			}
		}
    	
    	if(flg == 1) {
			model.addAttribute("data", list);
		} else {
			model.addAttribute("data", list2);
		}
        
        if(Integer.parseInt(beforeS) > 0 ) {
    		String s11 = Integer.toString(Integer.parseInt(beforeS) -10 );
	    	String s22 = Integer.toString(Integer.parseInt(beforeS) -1 );
	    	syokaiForm.setBefore(s11);
	    	syokaiForm.setAfter(s22);
	    	model.addAttribute("syokaiForm", syokaiForm);
        } else {
    		model.addAttribute("syokaiForm", syokaiForm);
    	}
        
		return "layout3";
	 }
    
    @RequestMapping(value = "/syokai", params="next", method = RequestMethod.POST)
	 public String form2(Model model, @ModelAttribute("syokai") SyokaiForm syokaiForm) {
    	model.addAttribute("loginForm",syokaiForm.getAuthority());
    	String afterS = syokaiForm.getAfter();
    	
    	String s1 = syokaiForm.getMakerName();
		String r1 = syokaiForm.getR1();
		String s2 = syokaiForm.getItemCode();
		String r2 = syokaiForm.getR2();
		String s3 = syokaiForm.getItemName();
		String r3 = syokaiForm.getR3();
		String s4 = syokaiForm.getPrice();
		String r4 = syokaiForm.getR4();
		if (s4.equals("")) {
			r4 = "no";
		}
		String s5 = syokaiForm.getStock();
		String r5 = syokaiForm.getR5();
		if (s5.equals("")) {
			r5 = "no";
		}
    	
		ArrayList<Map<String, Object>> list = (ArrayList<Map<String, Object>>) zaikoSyokaiDao.getZaikoSyokai2List(syokaiForm);
		
		ArrayList<Map<String,Object>> list2 = new ArrayList<Map<String,Object>>();
		
		int flg = 0;
		
		for(Map<String, Object> map : list) {
			
			if ("".equals(s1) && "".equals(s2) && "".equals(s3) && "".equals(s4) && "".equals(s5)) {
				flg = 1;
			}
			
			Object obj = map.get("S_PRICE");
			Object obj2 = map.get("O_STOCK");
			if((map.get("M_NAME").equals(s1) && r1.equals("yes")) || (map.get("S_CODE").equals(s2) && r2.equals("yes")) || (map.get("S_NAME").equals(s3) && r3.equals("yes")) || r4.equals("yes") && (Integer.parseInt(obj.toString()) >= Integer.parseInt(s4)) || r5.equals("yes") && (Integer.parseInt(obj2.toString()) >= Integer.parseInt(s5))) {
				System.out.println(map);
				list2.add(map);
			}
		}
		
		if(flg == 1) {
			model.addAttribute("data", list);
		} else {
			model.addAttribute("data", list2);
		}
        
    	if(flg == 1 && Integer.parseInt(afterS) < list.size() ) {
    		String s11 = Integer.toString(Integer.parseInt(afterS) + 1 );
	    	String s22 = Integer.toString(Integer.parseInt(afterS) + 10 );
	    	syokaiForm.setBefore(s11);
	    	syokaiForm.setAfter(s22);
	    	model.addAttribute("syokaiForm", syokaiForm);
    	} else if (flg != 1 && Integer.parseInt(afterS) < list2.size()) {
    		String s11 = Integer.toString(Integer.parseInt(afterS) + 1 );
	    	String s22 = Integer.toString(Integer.parseInt(afterS) + 10 );
	    	syokaiForm.setBefore(s11);
	    	syokaiForm.setAfter(s22);
	    	model.addAttribute("syokaiForm", syokaiForm);
    	} else {
    		model.addAttribute("syokaiForm", syokaiForm);
    	}
    	         
		 return "layout3";
	 }
    
    
    
    
    
    @RequestMapping(value="/syokai2", params="syokai2", method = RequestMethod.POST)
	public String syokai2(Model model, @ModelAttribute("syokai2") SyokaiForm syokaiForm) {
	model.addAttribute("syokaiForm",syokaiForm);
	model.addAttribute("loginForm",syokaiForm.getAuthority());
		
	ArrayList<Map<String, Object>> list = (ArrayList<Map<String, Object>>) zaikoSyokaiDao.getZaikoSyokai2List(syokaiForm);
		
	if(list.size() == 0) {
		model.addAttribute("result0","検索結果は0件です。");
		return "layout6";
	} else {
		model.addAttribute("data",list);
		return "layout7";
	}
	
	}

 @RequestMapping(value = "/syokai2", params="back", method = RequestMethod.POST)
 public String form4(Model model, @ModelAttribute("syokai2") SyokaiForm syokaiForm) {
	 model.addAttribute("loginForm",syokaiForm.getAuthority());
	String beforeS = syokaiForm.getBefore();
	
	String s1 = syokaiForm.getMakerName();
	String r1 = syokaiForm.getR1();
	String s2 = syokaiForm.getItemCode();
	String r2 = syokaiForm.getR2();
	String s3 = syokaiForm.getItemName();
	String r3 = syokaiForm.getR3();
	String s4 = syokaiForm.getPrice();
	String r4 = syokaiForm.getR4();
	if (s4.equals("")) {
		r4 = "no";
	}
	
	ArrayList<Map<String, Object>>  list =  (ArrayList<Map<String, Object>>) zaikoSyokaiDao.getZaikoSyokai2List(syokaiForm);
	
	ArrayList<Map<String,Object>> list2 = new ArrayList<Map<String,Object>>();
	
	int flg = 0;
	
	for(Map<String, Object> map : list) {
		
		if ("".equals(s1) && "".equals(s2) && "".equals(s3) && "".equals(s4)) {
			flg = 1;
		}
		
		Object obj = map.get("S_PRICE");
		if((map.get("M_NAME").equals(s1) && r1.equals("yes")) || (map.get("S_CODE").equals(s2) && r2.equals("yes")) || (map.get("S_NAME").equals(s3) && r3.equals("yes")) || r4.equals("yes") && (Integer.parseInt(obj.toString()) >= Integer.parseInt(s4))) {
			System.out.println(map);
			list2.add(map);
		}
	}
	
	if(flg == 1) {
		model.addAttribute("data", list);
	} else {
		model.addAttribute("data", list2);
	}
    
    if(Integer.parseInt(beforeS) > 0 ) {
		String s11 = Integer.toString(Integer.parseInt(beforeS) -10 );
    	String s22 = Integer.toString(Integer.parseInt(beforeS) -1 );
    	syokaiForm.setBefore(s11);
    	syokaiForm.setAfter(s22);
    	model.addAttribute("syokaiForm", syokaiForm);
    } else {
		model.addAttribute("syokaiForm", syokaiForm);
	}
    
	return "layout7";
 }

	@RequestMapping(value = "/syokai2", params="next", method = RequestMethod.POST)
	 public String form3(Model model, @ModelAttribute("syokai2") SyokaiForm syokaiForm) {
		model.addAttribute("loginForm",syokaiForm.getAuthority());
		String afterS = syokaiForm.getAfter();
		
		String s1 = syokaiForm.getMakerName();
		String r1 = syokaiForm.getR1();
		String s2 = syokaiForm.getItemCode();
		String r2 = syokaiForm.getR2();
		String s3 = syokaiForm.getItemName();
		String r3 = syokaiForm.getR3();
		String s4 = syokaiForm.getPrice();
		String r4 = syokaiForm.getR4();
		if (s4.equals("")) {
			r4 = "no";
		}
		
		ArrayList<Map<String, Object>> list = (ArrayList<Map<String, Object>>) zaikoSyokaiDao.getZaikoSyokai2List(syokaiForm);
		
		ArrayList<Map<String,Object>> list2 = new ArrayList<Map<String,Object>>();
		
		int flg = 0;
		
		for(Map<String, Object> map : list) {
			
			if ("".equals(s1) && "".equals(s2) && "".equals(s3) && "".equals(s4)) {
				flg = 1;
			}
			
			Object obj = map.get("S_PRICE");
			if((map.get("M_NAME").equals(s1) && r1.equals("yes")) || (map.get("S_CODE").equals(s2) && r2.equals("yes")) || (map.get("S_NAME").equals(s3) && r3.equals("yes")) || r4.equals("yes") && (Integer.parseInt(obj.toString()) >= Integer.parseInt(s4))) {
				System.out.println(map);
				list2.add(map);
			}
		}
		
		if(flg == 1) {
			model.addAttribute("data", list);
		} else {
			model.addAttribute("data", list2);
		}
	    
		if(flg == 1 && Integer.parseInt(afterS) < list.size() ) {
			String s11 = Integer.toString(Integer.parseInt(afterS) + 1 );
	    	String s22 = Integer.toString(Integer.parseInt(afterS) + 10 );
	    	syokaiForm.setBefore(s11);
	    	syokaiForm.setAfter(s22);
	    	model.addAttribute("syokaiForm", syokaiForm);
		} else if (flg != 1 && Integer.parseInt(afterS) < list2.size()) {
			String s11 = Integer.toString(Integer.parseInt(afterS) + 1 );
	    	String s22 = Integer.toString(Integer.parseInt(afterS) + 10 );
	    	syokaiForm.setBefore(s11);
	    	syokaiForm.setAfter(s22);
	    	model.addAttribute("syokaiForm", syokaiForm);
		} else {
			model.addAttribute("syokaiForm", syokaiForm);
		}
		         
		 return "layout7";
	 }
	
	@RequestMapping(value="/koushin2", method =  RequestMethod.POST)
		public String koushinChange(Model model, @ModelAttribute("koushin2") KoushinForm koushinForm) {
		model.addAttribute("loginForm",koushinForm.getAuthority());
		String sCODE = koushinForm.getBut();
		ArrayList<Map<String, Object>> list = (ArrayList<Map<String, Object>>) zaikoSyokaiDao.getZaikoKoushinList(sCODE);
		SyokaiForm syokaiForm = new SyokaiForm();
		for(Map<String, Object> map : list) {
			syokaiForm.setMakerName((String)map.get("M_NAME"));
			syokaiForm.setItemCode((String)map.get("S_CODE"));
			syokaiForm.setItemCode2((String)map.get("S_CODE"));
			syokaiForm.setItemName((String)map.get("S_NAME"));
			BigDecimal bc = (BigDecimal)map.get("S_PRICE");
			String str = bc.toString();
			syokaiForm.setPrice(str);
		}
		model.addAttribute("syokaiForm",syokaiForm);
		return "layout11";
	}
			
	
	@RequestMapping(value="/koushin", params="koushin", method = RequestMethod.POST)
	public String koushin1(Model model, @ModelAttribute("koushin") SyokaiForm syokaiForm) {
	model.addAttribute("syokaiForm",syokaiForm);
	model.addAttribute("loginForm",syokaiForm.getAuthority());
		
	ArrayList<Map<String, Object>> list = (ArrayList<Map<String, Object>>) zaikoSyokaiDao.getZaikoSyokai2List(syokaiForm);
		
	if(list.size() == 0) {
		model.addAttribute("result0","検索結果は0件です。");
		return "layout9";
	} else {
		model.addAttribute("data",list);
		return "layout10";
	}
	
	}

 @RequestMapping(value = "/koushin2", params="back", method = RequestMethod.POST)
 public String koushin2(Model model, @ModelAttribute("koushin2") SyokaiForm syokaiForm) {
	model.addAttribute("loginForm",syokaiForm.getAuthority());
	String beforeS = syokaiForm.getBefore();
	
	String s1 = syokaiForm.getMakerName();
	String r1 = syokaiForm.getR1();
	String s2 = syokaiForm.getItemCode();
	String r2 = syokaiForm.getR2();
	String s3 = syokaiForm.getItemName();
	String r3 = syokaiForm.getR3();
	String s4 = syokaiForm.getPrice();
	String r4 = syokaiForm.getR4();
	if (s4.equals("")) {
		r4 = "no";
	}
	
	ArrayList<Map<String, Object>>  list =  (ArrayList<Map<String, Object>>) zaikoSyokaiDao.getZaikoSyokai2List(syokaiForm);
	
	ArrayList<Map<String,Object>> list2 = new ArrayList<Map<String,Object>>();
	
	int flg = 0;
	
	for(Map<String, Object> map : list) {
		
		if ("".equals(s1) && "".equals(s2) && "".equals(s3) && "".equals(s4)) {
			flg = 1;
		}
		
		Object obj = map.get("S_PRICE");
		if((map.get("M_NAME").equals(s1) && r1.equals("yes")) || (map.get("S_CODE").equals(s2) && r2.equals("yes")) || (map.get("S_NAME").equals(s3) && r3.equals("yes")) || r4.equals("yes") && (Integer.parseInt(obj.toString()) >= Integer.parseInt(s4))) {
			list2.add(map);
		}
	}
	
	if(flg == 1) {
		model.addAttribute("data", list);
	} else {
		model.addAttribute("data", list2);
	}
    
    if(Integer.parseInt(beforeS) > 0 ) {
		String s11 = Integer.toString(Integer.parseInt(beforeS) -10 );
    	String s22 = Integer.toString(Integer.parseInt(beforeS) -1 );
    	syokaiForm.setBefore(s11);
    	syokaiForm.setAfter(s22);
    	model.addAttribute("syokaiForm", syokaiForm);
    } else {
		model.addAttribute("syokaiForm", syokaiForm);
	}
    
	return "layout10";
 }

	@RequestMapping(value = "/koushin2", params="next", method = RequestMethod.POST)
	 public String koushin3(Model model, @ModelAttribute("koushin2") SyokaiForm syokaiForm) {
		model.addAttribute("loginForm",syokaiForm.getAuthority());
		String afterS = syokaiForm.getAfter();
		
		String s1 = syokaiForm.getMakerName();
		String r1 = syokaiForm.getR1();
		String s2 = syokaiForm.getItemCode();
		String r2 = syokaiForm.getR2();
		String s3 = syokaiForm.getItemName();
		String r3 = syokaiForm.getR3();
		String s4 = syokaiForm.getPrice();
		String r4 = syokaiForm.getR4();
		if (s4.equals("")) {
			r4 = "no";
		}
		
		ArrayList<Map<String, Object>> list = (ArrayList<Map<String, Object>>) zaikoSyokaiDao.getZaikoSyokai2List(syokaiForm);
		
		ArrayList<Map<String,Object>> list2 = new ArrayList<Map<String,Object>>();
		
		int flg = 0;
		
		for(Map<String, Object> map : list) {
			
			if ("".equals(s1) && "".equals(s2) && "".equals(s3) && "".equals(s4)) {
				flg = 1;
			}
			
			Object obj = map.get("S_PRICE");
			if((map.get("M_NAME").equals(s1) && r1.equals("yes")) || (map.get("S_CODE").equals(s2) && r2.equals("yes")) || (map.get("S_NAME").equals(s3) && r3.equals("yes")) || r4.equals("yes") && (Integer.parseInt(obj.toString()) >= Integer.parseInt(s4))) {
				System.out.println(map);
				list2.add(map);
			}
		}
		
		if(flg == 1) {
			model.addAttribute("data", list);
		} else {
			model.addAttribute("data", list2);
		}
	    
		if(flg == 1 && Integer.parseInt(afterS) < list.size() ) {
			String s11 = Integer.toString(Integer.parseInt(afterS) + 1 );
	    	String s22 = Integer.toString(Integer.parseInt(afterS) + 10 );
	    	syokaiForm.setBefore(s11);
	    	syokaiForm.setAfter(s22);
	    	model.addAttribute("syokaiForm", syokaiForm);
		} else if (flg != 1 && Integer.parseInt(afterS) < list2.size()) {
			String s11 = Integer.toString(Integer.parseInt(afterS) + 1 );
	    	String s22 = Integer.toString(Integer.parseInt(afterS) + 10 );
	    	syokaiForm.setBefore(s11);
	    	syokaiForm.setAfter(s22);
	    	model.addAttribute("syokaiForm", syokaiForm);
		} else {
			model.addAttribute("syokaiForm", syokaiForm);
		}
		         
		 return "layout10";
	 }
	
	@RequestMapping(value="/sakuzyo", params="sakuzyo", method = RequestMethod.POST)
	public String sakuzyo1(Model model, @ModelAttribute("sakuzyo") SyokaiForm syokaiForm) {
	model.addAttribute("syokaiForm",syokaiForm);
	model.addAttribute("loginForm",syokaiForm.getAuthority());
		
	ArrayList<Map<String, Object>> list = (ArrayList<Map<String, Object>>) zaikoSyokaiDao.getZaikoSyokai2List(syokaiForm);
		
	if(list.size() == 0) {
		model.addAttribute("result0","検索結果は0件です。");
		return "layout12";
	} else {
		model.addAttribute("data",list);
		return "layout13";
	}
	
	}

 @RequestMapping(value = "/sakuzyo", params="back", method = RequestMethod.POST)
 public String sakuzyo2(Model model, @ModelAttribute("sakuzyo") SyokaiForm syokaiForm) {
	model.addAttribute("loginForm",syokaiForm.getAuthority());
	String beforeS = syokaiForm.getBefore();
	
	String s1 = syokaiForm.getMakerName();
	String r1 = syokaiForm.getR1();
	String s2 = syokaiForm.getItemCode();
	String r2 = syokaiForm.getR2();
	String s3 = syokaiForm.getItemName();
	String r3 = syokaiForm.getR3();
	String s4 = syokaiForm.getPrice();
	String r4 = syokaiForm.getR4();
	if (s4.equals("")) {
		r4 = "no";
	}
	
	ArrayList<Map<String, Object>>  list =  (ArrayList<Map<String, Object>>) zaikoSyokaiDao.getZaikoSyokai2List(syokaiForm);
	
	ArrayList<Map<String,Object>> list2 = new ArrayList<Map<String,Object>>();
	
	int flg = 0;
	
	for(Map<String, Object> map : list) {
		
		if ("".equals(s1) && "".equals(s2) && "".equals(s3) && "".equals(s4)) {
			flg = 1;
		}
		
		Object obj = map.get("S_PRICE");
		if((map.get("M_NAME").equals(s1) && r1.equals("yes")) || (map.get("S_CODE").equals(s2) && r2.equals("yes")) || (map.get("S_NAME").equals(s3) && r3.equals("yes")) || r4.equals("yes") && (Integer.parseInt(obj.toString()) >= Integer.parseInt(s4))) {
			System.out.println(map);
			list2.add(map);
		}
	}
	
	if(flg == 1) {
		model.addAttribute("data", list);
	} else {
		model.addAttribute("data", list2);
	}
    
    if(Integer.parseInt(beforeS) > 0 ) {
		String s11 = Integer.toString(Integer.parseInt(beforeS) -10 );
    	String s22 = Integer.toString(Integer.parseInt(beforeS) -1 );
    	syokaiForm.setBefore(s11);
    	syokaiForm.setAfter(s22);
    	model.addAttribute("syokaiForm", syokaiForm);
    } else {
		model.addAttribute("syokaiForm", syokaiForm);
	}
    
	return "layout13";
 }

	@RequestMapping(value = "/sakuzyo", params="next", method = RequestMethod.POST)
	 public String sakuzyo3(Model model, @ModelAttribute("sakuzyo") SyokaiForm syokaiForm) {
		model.addAttribute("loginForm",syokaiForm.getAuthority());
		String afterS = syokaiForm.getAfter();
		
		String s1 = syokaiForm.getMakerName();
		String r1 = syokaiForm.getR1();
		String s2 = syokaiForm.getItemCode();
		String r2 = syokaiForm.getR2();
		String s3 = syokaiForm.getItemName();
		String r3 = syokaiForm.getR3();
		String s4 = syokaiForm.getPrice();
		String r4 = syokaiForm.getR4();
		if (s4.equals("")) {
			r4 = "no";
		}
		
		ArrayList<Map<String, Object>> list = (ArrayList<Map<String, Object>>) zaikoSyokaiDao.getZaikoSyokai2List(syokaiForm);
		
		ArrayList<Map<String,Object>> list2 = new ArrayList<Map<String,Object>>();
		
		int flg = 0;
		
		for(Map<String, Object> map : list) {
			
			if ("".equals(s1) && "".equals(s2) && "".equals(s3) && "".equals(s4)) {
				flg = 1;
			}
			
			Object obj = map.get("S_PRICE");
			if((map.get("M_NAME").equals(s1) && r1.equals("yes")) || (map.get("S_CODE").equals(s2) && r2.equals("yes")) || (map.get("S_NAME").equals(s3) && r3.equals("yes")) || r4.equals("yes") && (Integer.parseInt(obj.toString()) >= Integer.parseInt(s4))) {
				System.out.println(map);
				list2.add(map);
			}
		}
		
		if(flg == 1) {
			model.addAttribute("data", list);
		} else {
			model.addAttribute("data", list2);
		}
	    
		if(flg == 1 && Integer.parseInt(afterS) < list.size() ) {
			String s11 = Integer.toString(Integer.parseInt(afterS) + 1 );
	    	String s22 = Integer.toString(Integer.parseInt(afterS) + 10 );
	    	syokaiForm.setBefore(s11);
	    	syokaiForm.setAfter(s22);
	    	model.addAttribute("syokaiForm", syokaiForm);
		} else if (flg != 1 && Integer.parseInt(afterS) < list2.size()) {
			String s11 = Integer.toString(Integer.parseInt(afterS) + 1 );
	    	String s22 = Integer.toString(Integer.parseInt(afterS) + 10 );
	    	syokaiForm.setBefore(s11);
	    	syokaiForm.setAfter(s22);
	    	model.addAttribute("syokaiForm", syokaiForm);
		} else {
			model.addAttribute("syokaiForm", syokaiForm);
		}
		         
		 return "layout13";
	 }
	
	
	
	

    
    
    @RequestMapping(value = "/zyutyu", params="2", method = RequestMethod.POST)
	public String zyutyu(Model model, @ModelAttribute("zyutyu") SyokaiForm syokaiForm) {
    	model.addAttribute("loginForm",syokaiForm.getAuthority());
    	ArrayList<Map<String, Object>> list1 = (ArrayList<Map<String, Object>>) zaikoSyokaiDao.getZaikoSyokai3List();
    	ArrayList<Map<String, Object>> list2 = (ArrayList<Map<String, Object>>) zaikoSyokaiDao.getZaikoSyokai4List();
    	ArrayList<Map<String, Object>> list3 = (ArrayList<Map<String, Object>>) zaikoSyokaiDao.getZaikoSyokai5List();
		
    	
		model.addAttribute("data1", list1);
		model.addAttribute("data2", list2);
		model.addAttribute("data3", list3);
		
		
		return "layout4";
	}
    
    @RequestMapping(value = "/zyutyu", method = RequestMethod.POST)
	public String zyutyuF(Model model, @ModelAttribute("zyutyu") SyokaiForm syokaiForm) {
    	model.addAttribute("loginForm",syokaiForm.getAuthority());
    	
    	ArrayList<Map<String, Object>> list1 = (ArrayList<Map<String, Object>>) zaikoSyokaiDao.getZaikoSyokai3List();
    	ArrayList<Map<String, Object>> list2 = (ArrayList<Map<String, Object>>) zaikoSyokaiDao.getZaikoSyokai0List(syokaiForm.getMakerName());
    	ArrayList<Map<String, Object>> list3 = (ArrayList<Map<String, Object>>) zaikoSyokaiDao.getZaikoSyokai00List(syokaiForm.getMakerName());
    	model.addAttribute("data1", list1);
		model.addAttribute("data2", list2);
		model.addAttribute("data3", list3);
		model.addAttribute("syokaiForm",syokaiForm);
    	return "layout4";
    }
    
    @RequestMapping(value = "/hattyu", params="3", method = RequestMethod.POST)
	public String hattyu(Model model, @ModelAttribute("hattyu") SyokaiForm syokaiForm) {
    	model.addAttribute("loginForm",syokaiForm.getAuthority());
    	
    	ArrayList<Map<String, Object>> list1 = (ArrayList<Map<String, Object>>) zaikoSyokaiDao.getZaikoSyokai3List();
    	ArrayList<Map<String, Object>> list2 = (ArrayList<Map<String, Object>>) zaikoSyokaiDao.getZaikoSyokai4List();
    	ArrayList<Map<String, Object>> list3 = (ArrayList<Map<String, Object>>) zaikoSyokaiDao.getZaikoSyokai5List();
		
    	
		model.addAttribute("data1", list1);
		model.addAttribute("data2", list2);
		model.addAttribute("data3", list3);
		
    	
		return "layout5";
	}
	
    @RequestMapping(value = "/hattyu", method = RequestMethod.POST)
    public String hattyuF(Model model, @ModelAttribute("hattyu") SyokaiForm syokaiForm) {
    	model.addAttribute("loginForm",syokaiForm.getAuthority());
    	
    	ArrayList<Map<String, Object>> list1 = (ArrayList<Map<String, Object>>) zaikoSyokaiDao.getZaikoSyokai3List();
    	ArrayList<Map<String, Object>> list2 = (ArrayList<Map<String, Object>>) zaikoSyokaiDao.getZaikoSyokai0List(syokaiForm.getMakerName());
    	ArrayList<Map<String, Object>> list3 = (ArrayList<Map<String, Object>>) zaikoSyokaiDao.getZaikoSyokai00List(syokaiForm.getMakerName());
    	model.addAttribute("data1", list1);
		model.addAttribute("data2", list2);
		model.addAttribute("data3", list3);
		model.addAttribute("syokaiForm",syokaiForm);
		return "layout5";
    }
}

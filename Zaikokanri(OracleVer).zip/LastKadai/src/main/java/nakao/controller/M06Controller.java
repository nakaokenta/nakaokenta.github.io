package nakao.controller;

import java.util.ArrayList;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import nakao.dao.ZaikoSakuzyoDao;
import nakao.form.SakuzyoForm;

@Controller
public class M06Controller {
	private ZaikoSakuzyoDao zaikoSakuzyoDao;
	
	public void setZaikoSakuzyoDao(ZaikoSakuzyoDao zaikoSakuzyoDao) {
		this.zaikoSakuzyoDao = zaikoSakuzyoDao;
	}
	

	@RequestMapping(value ="/sakuzyo", method = RequestMethod.POST)
	public String sakuzyo1(Model model, @ModelAttribute("sakuzyo") SakuzyoForm sakuzyoForm) {
		model.addAttribute("loginForm",sakuzyoForm.getAuthority());
		String s1 = sakuzyoForm.getBut();
		String result1 = "";
		String result2 = "";
		int count = 0;
		
		ArrayList<Map<String,Object>> list3 = (ArrayList<Map<String,Object>>) zaikoSakuzyoDao.getZaikoSakuzyoList(s1);
		
		for(Map<String, Object> map3 : list3) {
			result1 = (String) map3.get("M_CODE");
		}
		
		
		
		ArrayList<Map<String,Object>> list2 = (ArrayList<Map<String,Object>>) zaikoSakuzyoDao.getZaikoSakuzyo2List();
		
		for(Map<String, Object> map2 : list2) {
			result2 = (String) map2.get("S_MAKER_CODE");
			if(result1.equals(result2)) {
				count++;
				
			}
		}
		
		if(count > 1) {
			int updateResult1 = zaikoSakuzyoDao.updateZaikoSakuzyo(s1);
			int updateResult2 = zaikoSakuzyoDao.updateZaikoSakuzyo2(s1);
			if(updateResult1 == 1 && updateResult2 == 1) {			
				model.addAttribute("result", "商品の削除が正常に完了しました。");
			}
		} else if(count == 1) {
			int updateResult1 = zaikoSakuzyoDao.updateZaikoSakuzyo(s1);
			int updateResult2 = zaikoSakuzyoDao.updateZaikoSakuzyo2(s1);
			if(updateResult1 == 1 && updateResult2 == 1) {			
				model.addAttribute("result", "商品の削除が正常に完了しました。");
			}
			int updateResult0 = zaikoSakuzyoDao.updateZaikoSakuzyo0(result1);	
		}
		
			return "layout12";
	}
}

package nakao.controller;

import java.util.ArrayList;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import nakao.dao.ZaikoTsuikaDao;
import nakao.form.KoushinForm;
import nakao.form.LoginForm;
import nakao.form.SakuzyoForm;
import nakao.form.SyokaiForm2;
import nakao.form.TsuikaForm;

@Controller
public class M04Controller {
	private ZaikoTsuikaDao zaikoTsuikaDao;
	
	public void setZaikoTsuikaDao(ZaikoTsuikaDao zaikoTsuikaDao) {
		this.zaikoTsuikaDao = zaikoTsuikaDao;
	}
	
	@RequestMapping(value = "/syokai2", params="4", method = RequestMethod.POST)
	public String auth1(Model model,@ModelAttribute("syokai2") SyokaiForm2 syokaiForm2) {
		model.addAttribute("loginForm",syokaiForm2.getAuthority());
		return "layout6";
	}
	@RequestMapping(value = "/tsuika", params="5", method = RequestMethod.POST)
	public String auth2(Model model,@ModelAttribute("tsuika") TsuikaForm tsuikaForm) {
		model.addAttribute("loginForm",tsuikaForm.getAuthority());
		return "layout8";
	}
	@RequestMapping(value = "/koushin", params="6", method = RequestMethod.POST)
	public String auth3(Model model,@ModelAttribute("koushin") KoushinForm koushinForm) {
		model.addAttribute("loginForm",koushinForm.getAuthority());
		return "layout9";
	}
	@RequestMapping(value = "/sakuzyo", params="7", method = RequestMethod.POST)
	public String auth4(Model model,@ModelAttribute("sakuzyo") SakuzyoForm sakuzyoForm) {
		model.addAttribute("loginForm",sakuzyoForm.getAuthority());
		return "layout12";
	}
	
	
	@RequestMapping(value= "/tsuika", params="tsuika", method = RequestMethod.POST)
		public String tsuika(Model model,@Valid @ModelAttribute("tsuika") TsuikaForm tsuikaForm, BindingResult results) {
		model.addAttribute("tsuikaForm",tsuikaForm);
		model.addAttribute("loginForm",tsuikaForm.getAuthority());
		
		if(results.hasErrors()) {
			return "layout8";
		}
		String s1 = tsuikaForm.getMakerName();
		String s2 = tsuikaForm.getItemCode();
		String result0 = "";
		String result1 = "";
		String result2 = "";
		String result3 = "";
		String result4 = "";
		int flg = 0;
		
		ArrayList<Map<String,Object>> list0 = (ArrayList<Map<String,Object>>) zaikoTsuikaDao.getZaikoTsuika0List();
		
		for(Map<String, Object> map0 : list0) {
			result0 = (String) map0.get("S_CODE");
			if(s2.equals(result0)) {
				model.addAttribute("result", "入力された商品コードが存在しています。別の商品コードを入力してください。");
				return "layout7";
			}
		}
		
		ArrayList<Map<String,Object>> list = (ArrayList<Map<String,Object>>) zaikoTsuikaDao.getZaikoTsuikaList();
		
		for(Map<String, Object> map : list) {
			result1 = (String) map.get("M_NAME");
			result2 = (String) map.get("M_CODE");
			if(s1.equals(result1)) {
				result3 = result2;
				flg = 1;
				break;
			}
		}
		
		if(flg == 1) {
			int updateResult1 =  zaikoTsuikaDao.updateZaikoTsuika2(tsuikaForm,result3);
			int updateResult2 = zaikoTsuikaDao.updateZaikoTsuika3(tsuikaForm);
			
			if(updateResult1 == 1 && updateResult2 == 1) {
				model.addAttribute("result", "商品の追加が正常に完了しました。");
			}
			
		} else {
			int updateResult0 = zaikoTsuikaDao.updateZaikoTsuika(tsuikaForm);
			ArrayList<Map<String,Object>> list2 = (ArrayList<Map<String,Object>>) zaikoTsuikaDao.getZaikoTsuikaList();
			for(Map<String, Object> map : list2) {
				result1 = (String) map.get("M_NAME");
				result2 = (String) map.get("M_CODE");
				if(s1.equals(result1)) {
					result4 = result2;
					break;
				}
			}
			int updateResult1 =  zaikoTsuikaDao.updateZaikoTsuika2(tsuikaForm,result4);
			int updateResult2 = zaikoTsuikaDao.updateZaikoTsuika3(tsuikaForm);
			
			if( updateResult1 == 1 && updateResult2 == 1) {
				model.addAttribute("result", "商品の追加が正常に完了しました。");
			}
		}
		
		
		flg = 0;
		return "layout8";
	}
	
}

package nakao.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import nakao.dao.ZaikoZyutyuDao;
import nakao.form.SyokaiForm;
import nakao.form.SyokaiForm2;

@Controller
public class M03Controller {
	private ZaikoZyutyuDao zaikoZyutyuDao;
	
	public void setZaikoZyutyuDao(ZaikoZyutyuDao zaikoZyutyuDao) {
		this.zaikoZyutyuDao = zaikoZyutyuDao;
	}
	
	
	
	@RequestMapping(value = "/zyutyu", params="add1", method = RequestMethod.POST)
		public String zyutyu(Model model,@Valid @ModelAttribute("zyutyu") SyokaiForm syokaiForm, BindingResult results) {
	    	model.addAttribute("syokaiForm",syokaiForm);
	    	model.addAttribute("loginForm",syokaiForm.getAuthority());
	    	
	    	ArrayList<Map<String, Object>> list = (ArrayList<Map<String, Object>>) zaikoZyutyuDao.getZaikoZyutyuList();
	    	model.addAttribute("data", list);
	    	
	    	if(results.hasErrors()) {
	    		return "layout4";
	    	}
	    	String s1 = syokaiForm.getAccept();
	    	String s2 = syokaiForm.getItemCode();
	    	BigDecimal result00;
	    	int result000 = 0;
	    	
	    	ArrayList<Map<String, Object>> list0 = (ArrayList<Map<String, Object>>) zaikoZyutyuDao.getZaikoZyutyu000List(s2);
	    	for(Map<String, Object> map0 : list0) {
	    		result00 = (BigDecimal) map0.get("O_STOCK");
	    		result000 = result00.intValue();
	    	}
	    	
	    	int s11 = Integer.parseInt(s1);
	    	
	    	if(result000 - s11 <= 0) {
	    		model.addAttribute("result", "在庫数量が不足しているため、受注に失敗しました。");
	    	} else {
	    		int result = zaikoZyutyuDao.getZaikoZyutyu2List(s2,s1);
	    		model.addAttribute("result", "受注が正常に完了しました。");
	    	}
			
			ArrayList<Map<String, Object>> list1 = (ArrayList<Map<String, Object>>) zaikoZyutyuDao.getZaikoSyokai3List();
	    	ArrayList<Map<String, Object>> list2 = (ArrayList<Map<String, Object>>) zaikoZyutyuDao.getZaikoSyokai4List();
	    	ArrayList<Map<String, Object>> list3 = (ArrayList<Map<String, Object>>) zaikoZyutyuDao.getZaikoSyokai5List();
			
	    	
			model.addAttribute("data1", list1);
			model.addAttribute("data2", list2);
			model.addAttribute("data3", list3);
			
			
			return "layout4";
	}	
	 
	 @RequestMapping(value = "/hattyu", params="add2", method = RequestMethod.POST)
		public String zyutyu(Model model,@Valid @ModelAttribute("hattyu") SyokaiForm2 syokaiForm2, BindingResult results) {
	    	model.addAttribute("syokaiForm",syokaiForm2);
	    	model.addAttribute("loginForm",syokaiForm2.getAuthority());
	    	
	    	ArrayList<Map<String, Object>> list = (ArrayList<Map<String, Object>>) zaikoZyutyuDao.getZaikoZyutyuList();
	    	model.addAttribute("data", list);
	    	
	    	if(results.hasErrors()) {
	    		return "layout5";
	    	}
	
			int result = zaikoZyutyuDao.getZaikoZyutyu3List(syokaiForm2.getItemCode(),syokaiForm2.getRequest());
			
	    	System.out.println(result);
			
			if(result == 1) {
				model.addAttribute("result", "発注が正常に完了しました。");
			} 
			
			ArrayList<Map<String, Object>> list1 = (ArrayList<Map<String, Object>>) zaikoZyutyuDao.getZaikoSyokai3List();
	    	ArrayList<Map<String, Object>> list2 = (ArrayList<Map<String, Object>>) zaikoZyutyuDao.getZaikoSyokai4List();
	    	ArrayList<Map<String, Object>> list3 = (ArrayList<Map<String, Object>>) zaikoZyutyuDao.getZaikoSyokai5List();
			
	    	
			model.addAttribute("data1", list1);
			model.addAttribute("data2", list2);
			model.addAttribute("data3", list3);
			
			return "layout5";
	}	
}

package nakao.dao;

import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

public interface ZaikoSakuzyoDao {
	
	List<Map<String,Object>> getZaikoSakuzyoList(String s1) throws DataAccessException;
	List<Map<String,Object>> getZaikoSakuzyo2List() throws DataAccessException;
	int updateZaikoSakuzyo(String s1) throws DataAccessException;
	int updateZaikoSakuzyo2(String s1) throws DataAccessException;
	int updateZaikoSakuzyo0(String result1) throws DataAccessException;
}

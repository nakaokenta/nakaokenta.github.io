package nakao.dao;

import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

public interface ZaikoZyutyuDao  {
	
	List<Map<String, Object>> getZaikoZyutyu0List(String a) throws DataAccessException;
	
	List<Map<String,Object>> getZaikoZyutyuList() throws DataAccessException;
	
	int getZaikoZyutyu2List(String a, String b) throws DataAccessException;
	
	List<Map<String,Object>> getZaikoZyutyu000List(String s2) throws DataAccessException;
	
	int getZaikoZyutyu3List(String a, String b) throws DataAccessException;
	
	List<Map<String,Object>> getZaikoSyokai3List() throws DataAccessException;
	
	List<Map<String,Object>> getZaikoSyokai4List() throws DataAccessException;
	
	List<Map<String,Object>> getZaikoSyokai5List() throws DataAccessException;
}



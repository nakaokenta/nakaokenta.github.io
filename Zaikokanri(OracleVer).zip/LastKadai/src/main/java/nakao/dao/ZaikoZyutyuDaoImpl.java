package nakao.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;

public class ZaikoZyutyuDaoImpl extends  NamedParameterJdbcDaoSupport implements ZaikoZyutyuDao{
	
	public List<Map<String,Object>> getZaikoZyutyu0List(String a) throws DataAccessException {
		String sql = "SELECT * FROM ZAIKO_SYOUHIN LEFT JOIN ZAIKO_MAKER ON ZAIKO_SYOUHIN.S_MAKER_CODE = ZAIKO_MAKER.M_CODE LEFT JOIN ZAIKO_ORDER ON ZAIKO_SYOUHIN.S_CODE = ZAIKO_ORDER.O_SYOUHIN_CODE WHERE M_NAME = :M_NAME ORDER BY M_NAME,S_CODE";
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("M_NAME", a);
		return getNamedParameterJdbcTemplate().queryForList(sql,parameters);
	}
	
	public List<Map<String,Object>> getZaikoZyutyuList() throws DataAccessException {
		return getJdbcTemplate().queryForList("SELECT * FROM ZAIKO_SYOUHIN LEFT JOIN ZAIKO_MAKER ON ZAIKO_SYOUHIN.S_MAKER_CODE = ZAIKO_MAKER.M_CODE LEFT JOIN ZAIKO_ORDER ON ZAIKO_SYOUHIN.S_CODE = ZAIKO_ORDER.O_SYOUHIN_CODE ORDER BY M_NAME,S_CODE");
	}
	
	public int getZaikoZyutyu2List(String a, String b) throws DataAccessException {
		String sql = "UPDATE ZAIKO_ORDER SET O_ACCEPT = O_ACCEPT + ? , O_STOCK = O_STOCK - ? WHERE O_SYOUHIN_CODE = ?";
		return getJdbcTemplate().update(sql,b,b,a);
	}
	
	public List<Map<String, Object>> getZaikoZyutyu000List(String s2) throws DataAccessException {
		String sql = "SELECT * FROM ZAIKO_ORDER WHERE O_SYOUHIN_CODE = :O_SYOUHIN_CODE";
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("O_SYOUHIN_CODE", s2);
		return getNamedParameterJdbcTemplate().queryForList(sql,parameters);
		
	}
	
	public int getZaikoZyutyu3List(String a, String b) throws DataAccessException {
		String sql = "UPDATE ZAIKO_ORDER SET O_REQUEST = O_REQUEST + ? , O_STOCK = O_STOCK + ? WHERE O_SYOUHIN_CODE = ?";
		return getJdbcTemplate().update(sql,b,b,a);
	}
	
	public List<Map<String, Object>> getZaikoSyokai3List() throws DataAccessException {
		return getJdbcTemplate().queryForList("SELECT M_NAME FROM ZAIKO_MAKER GROUP BY M_NAME ORDER BY M_NAME");
	}
	
	public List<Map<String, Object>> getZaikoSyokai4List() throws DataAccessException {
		return getJdbcTemplate().queryForList("SELECT S_CODE FROM ZAIKO_SYOUHIN GROUP BY S_CODE ORDER BY S_CODE");
	}
	
	public List<Map<String, Object>> getZaikoSyokai5List() throws DataAccessException {
		return getJdbcTemplate().queryForList("SELECT S_NAME,S_CODE FROM ZAIKO_SYOUHIN ORDER BY S_NAME");
	}
}


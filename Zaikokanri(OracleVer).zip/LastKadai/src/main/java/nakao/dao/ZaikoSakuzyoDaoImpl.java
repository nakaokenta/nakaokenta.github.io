package nakao.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;

public class ZaikoSakuzyoDaoImpl extends NamedParameterJdbcDaoSupport implements ZaikoSakuzyoDao {
	
	public List<Map<String,Object>> getZaikoSakuzyoList(String s1){
		String sql = "SELECT * FROM ZAIKO_SYOUHIN LEFT JOIN ZAIKO_MAKER ON ZAIKO_SYOUHIN.S_MAKER_CODE = ZAIKO_MAKER.M_CODE	WHERE S_CODE = :S_CODE";
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("S_CODE",s1);
		return getNamedParameterJdbcTemplate().queryForList(sql,parameters);
	}
	
	public List<Map<String, Object>> getZaikoSakuzyo2List() throws DataAccessException {
		return getJdbcTemplate().queryForList("SELECT * FROM ZAIKO_SYOUHIN");
	}
	
	public int updateZaikoSakuzyo(String s1) throws DataAccessException {
		String sql = "DELETE FROM ZAIKO_SYOUHIN WHERE S_CODE = ?";
		return getJdbcTemplate().update(sql,s1);
	}
	
	public int updateZaikoSakuzyo2(String s1) throws DataAccessException {
		String sql = "DELETE FROM ZAIKO_ORDER WHERE O_SYOUHIN_CODE = ?";
		return getJdbcTemplate().update(sql,s1);
	}
	
	public int updateZaikoSakuzyo0(String result) throws DataAccessException {
		String sql = "DELETE FROM ZAIKO_MAKER WHERE M_CODE = ?";
		return getJdbcTemplate().update(sql,result);
	}
	
	
	
	
}

package nakao.dao;

import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

public interface ZaikoUsersDao {
	List<Map<String, Object>> getZaikoUsersList() throws DataAccessException;
}

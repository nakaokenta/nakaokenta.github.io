package nakao.dao;

import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class ZaikoUsersDaoImpl extends JdbcDaoSupport implements ZaikoUsersDao{
	public List<Map<String,Object>> getZaikoUsersList() throws DataAccessException {
		return getJdbcTemplate().queryForList("SELECT * FROM ZAIKO_USERS");
	}
}
